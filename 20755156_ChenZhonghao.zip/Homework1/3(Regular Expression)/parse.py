import re
from lxml import etree

print('Question1\n')
x = etree.parse('./blocklist.xml')
s = etree.tostring(x).decode()
ret1 = re.findall('<emItem blockID="[ig].*".*>',s)
for emItem in ret1:
    print(emItem)
print('*'*30)
print('\nQuestion2\n')
ret2 = re.findall(r'<.*id="[^\/^]+.*@.*".*>',s)
for emItem in ret2:
    print(emItem)